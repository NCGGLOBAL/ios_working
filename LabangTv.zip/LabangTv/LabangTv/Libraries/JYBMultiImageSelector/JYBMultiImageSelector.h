//
//  JYBMultiImageSelector.h
//  JYBMultiImageSelector
//
//  Created by 易达正丰 on 15/3/9.
//  Copyright (c) 2015年 易达正丰. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ELCImagePickerController.h"
#import "JYBMultiImageView.h"

