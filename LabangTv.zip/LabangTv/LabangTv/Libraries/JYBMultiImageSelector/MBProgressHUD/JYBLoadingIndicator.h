//
//  JYBLoadingIndicator.h
//  JinYuanBao
//
//  Created by 易达正丰 on 15/1/7.
//  Copyright (c) 2015年 newstep. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JYBLoadingIndicator : UIView

@end
